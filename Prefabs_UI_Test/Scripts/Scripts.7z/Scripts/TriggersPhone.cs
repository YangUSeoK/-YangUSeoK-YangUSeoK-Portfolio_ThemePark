﻿using UnityEngine;
using System.Collections;

public class TriggersPhone : MonoBehaviour {
	public bool SignalTrigger;
	public bool BatteryTrigger;
	public bool SMSTrigger;

	public int NumSignal, NumBattery;
	public string TextSMS;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
